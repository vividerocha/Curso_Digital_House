# jogo-da-velha-jquery
um jogo feito em Jquery e  javascript no final do modulo de Jquery do curso desenvolvedor web
<img src="https://github.com/marciojsalmeida/jogo-da-velha-jquery/blob/master/jogoVelha.jpg">
<img src="https://github.com/marciojsalmeida/jogo-da-velha-jquery/blob/master/jogoVelha2.jpg">
<img src="https://github.com/marciojsalmeida/jogo-da-velha-jquery/blob/master/jogoVelha3.jpg">
Para testar acesse : http://www.xp5.com.br/modelos/jogos/jogo-da-velha/
